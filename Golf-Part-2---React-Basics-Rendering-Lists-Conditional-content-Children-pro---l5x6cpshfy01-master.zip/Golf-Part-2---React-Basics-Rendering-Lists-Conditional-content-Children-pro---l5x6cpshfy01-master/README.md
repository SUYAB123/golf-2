# Hard Golf Game

 You have a golf ball that you want to move with keyboard keys.You are given a Start Button that begins the game and a Reset Button that restarts the game. To move the ball, appropriately update state variable <code>ballPosition</code>.When Game starts Ball should be inserted into DOM and Start button should be removed from DOM.

## Acceptance Criteria

- className of Ball should be <code>ball</code>.
- className of start button should be <code>start</code>.
- className of reset button should be <code>reset</code>.
- When Start button is clicked, the button should go away and the ball should appear.
- When Right,Left,Up,Down, Arrow  key is clicked on the keyboard, move the ball  by 5 pixel in respective direction.
- Don't Change prewritten function likerenderChoice. This can cause problem in validation of code.
